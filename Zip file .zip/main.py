from flask import Flask, request, jsonify
from binance.client import Client
import os

app = Flask(__name__)

API_KEY = os.environ.get("BINANCE_API_KEY")
API_SECRET = os.environ.get("BINANCE_SECRET_KEY")
WEBHOOK_PASSPHRASE = os.environ.get("WEBHOOK_PASSPHRASE")

client = Client(API_KEY, API_SECRET)

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json()

    if data.get("passphrase") != WEBHOOK_PASSPHRASE:
        return jsonify({"error": "Invalid passphrase"}), 403

    symbol = data.get("ticker")
    action = data.get("action")
    quantity = float(data.get("quantity"))

    try:
        if action == "buy":
            order = client.order_market_buy(symbol=symbol, quantity=quantity)
        elif action == "sell":
            order = client.order_market_sell(symbol=symbol, quantity=quantity)
        else:
            return jsonify({"error": "Invalid action"}), 400

        return jsonify(order)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/", methods=["GET"])
def home():
    return "Binance Trading Bot is running!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)